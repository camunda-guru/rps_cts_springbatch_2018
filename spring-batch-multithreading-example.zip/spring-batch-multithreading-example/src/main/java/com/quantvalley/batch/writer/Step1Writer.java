package com.quantvalley.batch.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

import com.quantvalley.batch.model.Trade;

public class Step1Writer implements ItemWriter<Trade>{

	@Override
	public void write(List<? extends Trade> arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
